package com.example.homework4thweek2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
